# Screening exercises
Please do the Powershell exercise, and as much as you can of the SQL exercise.
Please don't spend too much time on it - 2h should be the most anyone spends.

## Submitting your responses
Please create a ZIP file of your material.  Try not to include any object code, just source code if possible.
Then please attach your response to an email addressed to mharrah@paylocity.com

Thank you!