Function Save-JsonFile {
    param(
        [Parameter(Mandatory=$True)]
        [pscustomobject]
        $Json,

        [Parameter(Mandatory=$True)]
        [string]
        $Path
    )

    $js = $json | ConvertTo-Json -Compress
    $js | Set-Content -Path $Path

    # save Json as a single line in the path provided
}

Function Update-Json {
    param(
        [Parameter(Mandatory)]
        [string]
        $JsonString
    )

    # In the 'months' property, add a property to the Feburary object called 'weeks' which is an array of objects
    # For each week add a property called 'number' which will specify which week is represented. i.e. first week should have 'number' = 1
    # For each week add a property called 'days' which is an array of objects. Assume week is Sunday to Saturday
    # For each day of the week add a 'Date' property that specifies the date of the month (i.e. 1, 2, 3, etc) and the day of the week as a string (i.e. Monday, Tuesday, etc)

    $JsonString
}
