function Find-RunningWServices {
    Get-Service -Name 'W*' |
    Where-Object { $_.Status -eq 'Running' } |
    Select-Object -Property Name,DisplayName 
}

function Test-IsOdd {
    param(
        [int]
        $Number
    )

    Set-StrictMode -Version Latest
    $isOdd = ($Number % 2) -eq 0
    Write-Output $isOdd
}

function Get-FooCount {
    Set-StrictMode -Version Latest

    function foo {
        # Do not change this inner function
        $r = @("hi")
        return $r
    }

    (foo | measure-object).Count
}

function Add-IntFiles {
    param(
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({ Test-Path -Path $_ })]
        [string]
        $FirstPath,
        
        [Parameter(Mandatory=$True)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({ Test-Path -Path $_ })]
        [string]
        $SecondPath
    )
    
    # Fix this without modifying the called script
    $val1 = . $PsScriptRoot\Get-IntFromFile.ps1 -Path $FirstPath
    $val2 = . $PsScriptRoot\Get-IntFromFile.ps1 -Path $SecondPath
    $ret = $val1 + $val2
    return $ret
}
