function Write-Stuff {
    param(
        [string]$Phrase
    )
    
    $Phrase
}

function Write-Stuff2 {
    param(
        [String[]]$obj
    )
    
    $obj
}

function Write-PID {
    param(
        [System.Diagnostics.Process]
        $Process
    )
    
    # Avoid string concat
    "Hi $($Process.Id)"
}
