#Requires -Modules Pester

Describe 'Advanced Funcs' {
    BeforeAll {
        $sutPath = Join-Path -Path ((Get-Item $PSScriptRoot).Parent.FullName) -ChildPath "sut/AdvancedFunctions.ps1"
        . $sutPath
        $filesPath = Join-Path -Path ((Get-Item $PSScriptRoot).Parent.FullName) -ChildPath "files"
    }
    
    
    Context "Get-FullPath" {
        It "Should return same number of entries" {
            $files = @(Get-ChildItem -Path $filesPath)
            $fullPaths = @($files | Get-FullPath)
            $files.Count | Should -BeExactly $fullPaths.Count
        }
    }
    
    Context "Get-TextFileContent" {
        It "Should return 'hi: 20'" {
            Get-TextFileContent -Path $filesPath | Should -BeExactly "hi: 20"
        }
        
        It "Should return null on missing file" {
            Get-TextFileContent -Path $filesPath -FileName '21.txt' | Should -BeNullOrEmpty
        }
    }
}
