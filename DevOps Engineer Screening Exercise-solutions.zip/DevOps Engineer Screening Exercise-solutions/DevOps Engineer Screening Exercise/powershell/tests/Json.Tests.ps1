#Requires -Modules Pester

Describe "JSON Manipulation" {
    BeforeAll {
        $sutPath = Join-Path -Path ((Get-Item $PSScriptRoot).Parent.FullName) -ChildPath "sut/Json.ps1"
        . $sutPath

        $srcJson = @"
{
    "months": [
        {
            "name": "February",
            "numberOfDays": 28,
            "canHaveVariableNumberOfDays": true   
        }
    ],
    "year": 2023
}
"@
        [pscustomobject]$srcObject = @{
            year = 2023
            months = @(
                @{
                    name = 'February'
                    numberOfDays = 28
                    canHaveVariableNumberOfDays = $true
                }
            )
        }
    }

    Context "Save-JsonFile (with relative path)" {
        BeforeAll {
            Push-Location $env:TEMP
            $fileName = [io.path]::GetRandomFileName()
            $relativePath = ".\$fileName"
            $fullPath = Join-Path $env:TEMP $fileName
            Save-JsonFile -Json $srcObject -Path $relativePath
            Pop-Location
        }
        
        It "Should save a file" {
            Test-Path -Path $fullPath | Should -BeTrue
        }

        It "Should be valid json" {
            $savedJson = (Get-Content -Path $fullPath -Raw) | ConvertFrom-Json
            $savedJson | Should -BeOfType PSCustomObject
        }

        It "Should have defined properties in deserialized object" {
            $savedJson = (Get-Content -Path $fullPath -Raw) | ConvertFrom-Json
            $savedJson.months | Should -Not -BeNullOrEmpty
        }

        It "Should have only 1 line in file" {
            $savedJsonLines = Get-Content -Path $fullPath
            $savedJsonLines.Count | Should -BeExactly 1
        }
    }

    Context "Update-Json" {
        BeforeAll {
            $updatedJsonString = Update-Json -JsonString $srcJson
            $updatedJson = $updatedJsonString | ConvertFrom-Json -Depth 99
        }

        It "Json should still have a 'months' array property" {
            $updatedJson.months | Should -Not -BeNullOrEmpty
            ,$updatedJson.months | Should -BeOfType System.Array
            $updatedJson.months.Count | Should -BeExactly 1
        }

        It "Json should still have a year property" {
            $updatedJson.year | Should -Not -BeNullOrEmpty
            $updatedJson.year | Should -BeExactly 2023
        }

        It "February should have a weeks array property" {
            $february = $updatedJson.months | Where-Object name -eq 'February'
            ,$february.weeks | Should -BeOfType array
            $february.weeks.Count | Should -BeGreaterThan 0
        }

        It "Each week of February should have array of days and week number property" {
            $february = $updatedJson.months | Where-Object name -eq 'February'
            $february.weeks.Count | Should -BeGreaterThan 0
            foreach($week in $february.weeks) {
                $week.number | Should -BeGreaterThan 0
                ,$week.days | Should -BeOfType array
                $week.days.Count | Should -BeGreaterThan 0
                foreach($day in $week.days) {
                    $day.Day | Should -BeOfType long
                    $day.Day | Should -BeGreaterThan 0
                    $day.DayOfWeek | Should -BeIn ([enum]::GetNames([System.DayOfWeek]))
                }
            }
        }
    }
}
