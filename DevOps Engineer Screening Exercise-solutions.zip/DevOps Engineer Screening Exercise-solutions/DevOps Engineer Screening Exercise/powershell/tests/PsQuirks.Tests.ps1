#Requires -Modules Pester

Describe "PsQuirks" {
    BeforeAll {
        $sutPath = Join-Path -Path ((Get-Item $PSScriptRoot).Parent.FullName) -ChildPath "sut/PsQuirks.ps1"
        . $sutPath
    }
    
    Context "Find-RunningWServices" {
        It "Should return at least 1 service" {
            @(Find-RunningWServices).Count | Should -BeGreaterThan 0
        }
    }
    
    Context "Test-IsOdd" {
        It "Should Return Bool" {
            Test-IsOdd -Number 2 | Should -BeOfType System.Boolean
        }
    }
    
    Context "Get-FooCount" {
        It "Should have a count of 1" {
            Get-FooCount | Should -BeExactly 1
        }
    }
    
    Context "Add-IntFiles" {
        It "Should Add File Contents as ints" {
            $filesPath = "$PsScriptRoot\..\files"
            $r = Add-IntFiles -FirstPath "$filesPath\12.txt" -SecondPath "$filesPath\4.txt"
            $r | Should -BeExactly (12+4)
        }
    }
}