#Requires -Modules Pester

Describe 'Write-Stuff' {
    BeforeAll {
        $sutPath = Join-Path -Path ((Get-Item $PSScriptRoot).Parent.FullName) -ChildPath "sut/Write-Stuff.ps1"
        . $sutPath
    }
    
    Context 'Write-Stuff' {
        It "Should Write 'hi'" {
            Write-Stuff -Phrase 'hi' | Should -Be "hi"
        }
    }
    
    Context 'Write-Stuff2' {
        It "Should Write 'hi'" {
            Write-Stuff2 @($null,'hi') | Should -Be 'hi'
        }
    }
    
    Context "Write-PID" {
        It "Should Write PID" {
            $psProcesses = @(Get-Process -Name 'powershell')
            Write-PID -Process $psProcesses[0] | Should -Match 'Hi\s+\d+'
        }
    }
}
