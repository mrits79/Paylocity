﻿Insert into Deploys(Package, Environment, DateComplete) values
('AAA', 'ZZZ', '2/16/2015'),
('BBB', 'ZZZ', '2/24/2015'),
('AAA', 'ZZZ', '2/25/2015'),
('AAA', 'ZZZ', '2/22/2015'),
('CCC', 'ZZZ', '2/24/2015'),
('AAA', 'YYY', '2/24/2015'),
('BBB', 'YYY', '2/21/2015')

Insert into Requests(Package, Environment, DateComplete) values
('AAA', 'ZZZ', '2/22/2015'),
('BBB', 'ZZZ', '2/22/2015'),
('AAA', 'ZZZ', '2/22/2015'),
('AAA', 'ZZZ', '2/22/2015'),
('CCC', 'ZZZ', '2/22/2015'),
('AAA', 'YYY', '2/22/2015'),
('BBB', 'YYY', '2/22/2015')

Insert into LastChange(Package, Environment) values
('AAA', 'ZZZ'),
('BBB', 'ZZZ'),
('CCC', 'ZZZ'),
('AAA', 'YYY'),
('BBB', 'YYY')