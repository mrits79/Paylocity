-- DISCLAMIER : I am not a DBA but have dabled with sql scripts here and there. 

-- First creating a Temp result for doing a max(datecomplete) on each side of the of the table with a union to combine the results

;WITH all_records
    AS (
    SELECT package, environment, Max(datecomplete) AS Latest_Date FROM
deploys GROUP  BY package, environment
UNION
        SELECT package, environment, Max(datecomplete) AS Latest_Date
FROM  requests R GROUP  BY package, environment
),

-- Creating a final reults with a max on the date grouped by package and environment 

    final AS
(
SELECT package,  environment, Max(latest_date) AS Latest_Date FROM
all_records GROUP  BY package, environment
)

-- updating the records from final table to LatestChange table for the date-complete column with the inner join to make sure to update data only if they match

UPDATE LC
SET    [DateComplete] = F.latest_date
FROM  [dbo].[lastchange] AS LC
      INNER JOIN final AS F
              ON LC.package = F.package
  AND LC.environment = F.environment;